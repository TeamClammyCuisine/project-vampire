The font file in this archive was created by Jorge Moreno.
Contact: jmo2814@gmail.com
if you want to use this font in any comercial form just ask. 
i'll probably say yes